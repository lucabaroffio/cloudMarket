""" database config """

#rds settings
rds_host  = "db.cgd6gebzxrev.us-east-1.rds.amazonaws.com"
username = "skaluke"
password = "wcassano"
db_name = "cloud_jobs"
port = "5432"
